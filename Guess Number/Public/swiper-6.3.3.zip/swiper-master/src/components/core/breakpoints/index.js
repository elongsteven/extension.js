import setBreakpoint from './setBreakpoint';
import getBreakpoint from './getBreakpoint';

export default { setBreakpoint, getBreakpoint };
